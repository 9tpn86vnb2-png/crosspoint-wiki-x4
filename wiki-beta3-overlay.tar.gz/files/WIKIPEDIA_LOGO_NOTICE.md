# Wikipedia puzzle-globe artwork

The Wikipedia globe is artwork of Wikimedia / the Wikimedia Foundation; version
1 by Nohat, based on the concept by Paullusmagnus. The user supplied the PNG used
for this build. Reference attribution and license:
https://commons.wikimedia.org/wiki/File:Wikipedia-logo-v2.svg
https://creativecommons.org/licenses/by-sa/3.0/

The included bitmap derivatives are resized to 112 and 64 pixels, composited
against white, and dithered to monochrome for the X4 display. Those artwork
derivatives remain under CC BY-SA 3.0, not the firmware source's MIT license.
Wikipedia and Wikimedia marks remain subject to the Wikimedia trademark policy:
https://foundation.wikimedia.org/wiki/Policy:Trademark_policy
This unofficial offline reader is not endorsed by the Wikimedia Foundation.

Source PNG SHA-256: a1855439029de0d3567697b5691a07af96b74a8baaee9b060d88d45c912e2074
