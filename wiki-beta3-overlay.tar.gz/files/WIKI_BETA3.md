# CrossPoint + Wiki beta 3 — original Xteink X4

This is an unofficial, experimental application-only update to the working
CrossPoint 1.6.0 Wiki beta. A successful build is not a physical X4 test.

## Updating

Use the same original-X4 Custom .bin application-update route that worked for
beta 2. Select `crosspoint-1.6.0-wiki-beta3-x4-UNTESTED.bin`, not the ZIP.
Keep the beta 2 binary as a fallback and back up the SD card/settings first.
Do not erase flash, change partitions, use address zero, or merge this with
other binaries. This is not for the ESP32-S3 X4 Pro or X4 Classic.

Keep your existing `wikipedia.cdb` and the `/.crosspoint/wiki/` folder in place.
No encyclopedia replacement, saved-article migration or coding is required.
For actual Times New Roman, install your own licensed font through CrossPoint's
SD-card font system and select that family in Wiki > Text options. The firmware
does not bundle Times New Roman font files. Existing beta 2 saved articles use
the same files.

## Changes

- The Wiki start screen shows the supplied Wikipedia puzzle-globe above
  "Wikipedia", reduced and dithered for the monochrome display. The small
  circle-grid icon in CrossPoint's main menu remains unchanged.
- Article titles and recognized section headings now use the same selected
  CrossPoint reader font family as article body text, rendered bold and scaled
  larger (title 4/3, section heading 6/5). This means a user-installed
  `TimesNewRoman` SD-card family can style the whole article consistently.
  Headings missing from the flattened encyclopedia pack cannot be reconstructed.
- Article options now says **Save Article**, or **Remove Saved Article** for
  an already-saved article. The Bookmarks list and on-card save format remain
  compatible. The success message now says "Article saved".
- **Text options** opens CrossPoint's native text-settings screen with its
  Font, Size and Layout tabs. It includes Noto Serif, Noto Sans, and compatible
  SD-card font families already installed through CrossPoint's normal font
  system. Available point sizes come from the selected family: built-ins
  have 12, 14, 16 and 18 point; SD families offer their installed sizes.

## Text settings: important behavior

These are the **same shared reading settings used by ordinary CrossPoint
books**, not a second list of fake or look-alike fonts. Changing the font,
size, line spacing, extra paragraph spacing, alignment or margins here also
changes those settings for books. On entering Wiki, the current book font is
used; the former Wiki-only three-size preference is no longer used.

The native Font/Size/Layout controls retain their standard navigation and
font preview. The native Style tab is deliberately hidden only when opened
from Wiki: EPUB CSS, focus-reading, hyphenation and grayscale-AA options are
not implemented for WCDB, so they are not advertised as working controls.
Ordinary EPUB text settings still have all four tabs and unchanged defaults.
The preview disables focus-reading and hyphenation in Wiki context only.

Wiki applies line spacing, paragraph spacing, margins and left/center/right
alignment. Justify (and Book's Style, since this pack has no CSS) spreads
word spaces on suitable nonfinal left-to-right body lines; short sparse
lines and complex-script runs are not stretched. It is not the full EPUB
layout engine. Existing reference/caption cleanup remains optional.

The article is repaginated and returns to page 1 after changing text options.
Archive buffers are released while the native font preview is open, then the
same article is reopened. Missing/removed data is reported rather than using
stale text. Compatible installed SD fonts use the existing native loader and
bounded per-run glyph preparation; performance with large font families still
needs device testing. Very large installed sizes that cannot fit even one
line produce a message directing you back to Text options.

## Controls

Wiki starts with Search, Random article and Bookmarks as in beta 2.
While reading: tap Confirm for Article options; hold Confirm to save/remove
an article. Side keys turn pages; front Left/Right change archive entries.
Tap Back returns to Wiki start, then Back again returns to CrossPoint.
Hold Back cycles the selected native family's available point sizes.
Font/layout choices persist through the normal CrossPoint settings store.
The clean/original text toggle remains in Article options.

## What did not change

Text-only WCDB, not ZIM. The encyclopedia pack still contains no embedded
article images. Adding the static start-screen logo does not add images to
articles. No online downloads, full-text search, selectable in-article links,
page-position bookmarks or Microreader engine are included in this update.
The 64-saved-article / 16 KiB title-storage limits remain in place.

The compatible published Simple English Wikipedia pack remains unchanged:
https://github.com/Sparkadium/crosspoint-reader-almanac/releases/download/v1.1.0-almanac/wikipedia.cdb
Size: 48,523,777 bytes.
SHA-256: c994f024322352de9e8ec96092834b2296f2304400337a016dc7a8eedf0e2b30
Content: Simple English Wikipedia contributors, applicable CC BY-SA;
WCDB compilation by Sparkadium / CrossInk Almanac. Not all of English Wikipedia.

Logo attribution, artwork license and modification details are in
WIKIPEDIA_LOGO_NOTICE.md. This firmware is not endorsed by Wikimedia.
No separate font files are included in the download.

## Build and validation

CrossPoint base: 54337e6d73fc628f4ba523ddc89a743ca8c6e4c5 (1.6.0).
This build retains the native WCDB decoder tests and complete reference-pack
comparison from beta 2. Beta 3 additionally runs UI/navigation/persistence and
font-setting tests with host storage/font adapters, plus the actual enlarged
heading painter using native EpdFont, UTF-8 and BiDi source with synthetic glyph
bitmaps and a simulated pixel target. All run with ASan/UBSan; they are not an
ESP32 emulator or physical-display validation.

The isolated source overlay validates every original source hash before
writing changed files. The emitted changed source, exact build identity,
image inspection, partition-fit checks and test logs accompany the candidate.
Firmware bytes are never patched after the compiler produces them.
See build-manifest.json for the successful build's exact results.

First device checks: open Wiki and inspect the logo; search and open an article;
check its bold title; Save Article and reopen it; test Font/Size/Layout and return
to the same article; try an ordinary EPUB, then sleep/wake. Retain beta 2 and use
only your established recovery route if beta 3 restarts or freezes repeatedly.

## Times New Roman note

Times New Roman is proprietary and is not included in this firmware. CrossPoint
can convert a font you are licensed to use into `.cpfont` files. Use a family
name without spaces, such as `TimesNewRoman`, install the generated sizes under
`/fonts/TimesNewRoman/` (or the hidden `/.fonts/TimesNewRoman/`), then select it
from Wiki > Article options > Text options > Font. Body text, article titles and
recognized section headings will then all use that family; bold headings use
the font's bundled bold style. If the family is not installed, the selected
built-in CrossPoint font remains the fallback. Because beta 3 currently uses
CrossPoint's shared native text settings, selecting TimesNewRoman there also
selects it for ordinary books.
